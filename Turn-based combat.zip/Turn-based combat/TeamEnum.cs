﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Turn_based_combat
{
    public enum Team
    {
        Player,
        Enemy,
        Neutral
    }
}
